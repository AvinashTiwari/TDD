package com.hanselnpetal.domain;

public class DeliveryAddress {

}
